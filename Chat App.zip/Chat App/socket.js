const express = require("express");
const socketIO = require("socket.io");
const path = require("path");
const app = express();

const server = app.listen(3000,()=>{
    console.log("SUIIIIIIIIIIIII")
});

const io = socketIO(server); //it creates socketIO.io instance attached to the express server.

app.use(express.static(path.join(__dirname,'/public'))); //Serves static files(like HTML, CSS, Javascript) located in the public directory.

io.on('connection',socket=>{
    console.log("A user connected");

    socket.on('chat message',msg=>{
        io.emit('chat message',msg);
    });

    socket.on('disconnect',()=>{
        console.log("A User Disconnected");
    });
});




